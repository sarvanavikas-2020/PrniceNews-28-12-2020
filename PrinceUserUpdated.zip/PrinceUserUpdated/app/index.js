'use strict';

angular.module('myApp.index', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/!', {
    templateUrl: 'index.html',
    controller: 'indexCtrl'
  });
}])

.controller('indexCtrl', [function() {

}]);