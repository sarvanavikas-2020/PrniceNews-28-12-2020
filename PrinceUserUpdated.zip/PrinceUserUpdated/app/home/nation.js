'use strict';

angular.module('myApp.nation', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/nation', {
    templateUrl: 'home/nation.html',
    controller: 'natctrl'
  });
}])

.controller('natctrl', [function() {

}]);