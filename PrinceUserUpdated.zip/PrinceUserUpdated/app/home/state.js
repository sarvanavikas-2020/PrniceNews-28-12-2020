'use strict';

angular.module('myApp.state', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/state', {
    templateUrl: 'home/state.html',
    controller: 'stateCtrl'
  });
}])

.controller('stateCtrl', [function() {

}]);