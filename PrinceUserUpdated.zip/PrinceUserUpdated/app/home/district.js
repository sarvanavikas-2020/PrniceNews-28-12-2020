'use strict';

angular.module('myApp.district', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/district', {
    templateUrl: 'home/district.html',
    controller: 'districtCtrl'
  });
}])

.controller('districtCtrl', [function() {

}]);