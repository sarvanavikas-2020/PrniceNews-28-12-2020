'use strict';

angular.module('myApp.filmy', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/filmy', {
    templateUrl: 'home/filmy.html',
    controller: 'filmyCtrl'
  });
}])

.controller('filmyCtrl', [function() {

}]);