'use strict';

angular.module('myApp.political', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/political', {
    templateUrl: 'home/political.html',
    controller: 'politicalCtrl'
  });
}])

.controller('politicalCtrl', [function() {

}]);