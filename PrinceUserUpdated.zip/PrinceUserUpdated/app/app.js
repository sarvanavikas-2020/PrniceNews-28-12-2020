

        var myApp = angular.module("myApp", []);
        myApp.controller('myController', function ($scope, $http) {
            $scope.users = {};
            $scope.upcoming = {};
            allNews();
            quaryAllCat();
			
			
            getNewsBydistricts();
             getNewsByState();
             getNewsByUpComing();

//queary all distsricts by id 1======================================================================================
            function getNewsBydistricts() {
                $http({
                    method: 'GET',
                    url: ('https://princetv.cloudjiffy.net/PrinceNewsWeb/news/v1/getNewsByCatId/1'),
                }).then(function successCallback(response) {
                    $scope.districts = response.data;
                        console.log($scope.districts);
                    angular.forEach($scope.news, function (item) {
                        console.log(item.newsFieldDto);
                    })

                }, function errorCallback(response) {
                    console.log($scope.districts);
                }
                );
            }
			
			
			myApp.filter('trusted', ['$sce', function ($sce) {
        return function(youtube) {
        		var video_id = youtube.split('v=')[1].split('&')[0];
                            return $sce.trustAsResourceUrl(" https://www.youtube.com/embed/" + video_id);
        };
    }]);


//=======================================queary all states by id 2==============================================

            function getNewsByState() {
                $http({
                    method: 'GET',
                    url: ('https://princetv.cloudjiffy.net/PrinceNewsWeb/news/v1/getNewsByCatId/2'),
                }).then(function successCallback(response) {
                    $scope.state = response.data;
                    console.log($scope.state);

                    angular.forEach($scope.news, function (item) {
                        console.log(item.newsFieldDto);
                    })

                }, function errorCallback(response) {
                    console.log($scope.state);
                }
                );
            }

//onclick news display  news (query by news id) in state////////////////////////////////
            
$scope.show=function(s){
    console.log(s);
    console.log(s.newsId);

   $scope.newsId= s.newsId;


    $http({
        method: 'GET',
        url: ('https://princetv.cloudjiffy.net/PrinceNewsWeb/news/v1/queryNewsByNewsId/'+$scope.newsId),
    }).then(function successCallback(response) {
        $scope.newsName = response.data.newsName;
        $scope.discription = response.data.discription;
        $scope.youtube = response.data.youtube;
        $scope.insertedDate = response.data.insertedDate;
        console.log ( $scope.newsName );
         console.log ( $scope.insertedDate );
     }, function errorCallback(response) {
        console.log($scope.newsName);
    }
    );

    $scope.newsName=newsName;
    $scope.discription=description;
    $scope.youtube =youtube;
    $scope.insertedDate=insertedDate;



}

//queary all upcoming events by id 13=======================================================================
            function getNewsByUpComing() {
                $http({
                    method: 'GET',
                    url: ('https://princetv.cloudjiffy.net/PrinceNewsWeb/news/v1/getNewsByCatId/13'),
                }).then(function successCallback(response) {
                    $scope.upcoming = response.data;
                 }, function errorCallback(response) {
                    console.log($scope.upcoming.newsFieldDto);
                }
                );
            }


//query all category==============================================================================================
            function quaryAllCat() {
                $http({
                    method: 'GET',
                    url: ('https://princetv.cloudjiffy.net/PrinceNewsWeb/category/v1/queryAllCategory'),
                }).then(function successCallback(response) {
                    $scope.users = response.data;
                   
                    console.log($scope.users);
                    angular.forEach($scope.users, function (item) {
                        //console.log(item.newsFieldDto);  
                    })
                }, function errorCallback(response) {
                    console.log(response.statusText);
                }
                );

            }


 /////////////query all news===========================================================================================           
            function allNews() {
                $http({
                    method: 'GET',
                    url: ('https://princetv.cloudjiffy.net/PrinceNewsWeb/news/v1/queryAllNews'),
                }).then(function successCallback(response) {
                    $scope.allNews = response.data;
                    console.log($scope.allNews);

                   

                }, function errorCallback(response) {
                    console.log($scope.allNews);
                }
                );
            }


        });
    