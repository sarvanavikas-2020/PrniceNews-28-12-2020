﻿
var app = angular.module('myApp', ['ngRoute']);

app.config(function ($routeProvider) {
    $routeProvider
        .when('/dummy', {
            templateUrl: 'owner/dummy.html'
        })
        .when('/renthouse', {
            templateUrl: 'owner/renthouse.html'
        })
        .when('/file-structure', {
            templateUrl: 'owner/tenants.html'
        })
        .otherwise({ redirectTo: 'owner/DashBoard.html' });
              
});

app.run(function ($rootScope, $location) {
    $rootScope.$on("$routeChangeSuccess", function (event, next, current) {
        $rootScope.url = $location.$$path.replace('/', '');
    });
});

function routeChanged(scope, callback) {
    scope.$on('$routeChangeSuccess', callback());
}


$(function () {
    $.AdminBSB.leftSideBar.activate();
    $.AdminBSB.navbar.activate();
});