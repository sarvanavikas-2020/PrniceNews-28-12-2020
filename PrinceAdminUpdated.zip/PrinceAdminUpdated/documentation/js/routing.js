//Define an angular module for our app
var sampleApp = angular.module('myApp', []);

//Define Routing for app
//Uri /AddNewOrder -> template AddOrder.html and Controller AddOrderController
//Uri /ShowOrders -> template ShowOrders.html and Controller AddOrderController
myApp.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider
       
     .when('/renthouse',  { templateUrl: 'templates/renthouse.html',
	                            controller: 'ShowOrdersController' })
                                
     .when('/tenants',  { templateUrl: 'templates/tenants.html',
	                            controller: 'ShowOrdersController' })
	                            
      .otherwise({ redirectTo: 'templates/DashBoard.html' });
}]);

